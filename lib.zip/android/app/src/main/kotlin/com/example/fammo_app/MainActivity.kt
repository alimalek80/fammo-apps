package com.example.fammo_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
